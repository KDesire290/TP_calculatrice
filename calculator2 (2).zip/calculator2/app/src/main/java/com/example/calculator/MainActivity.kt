package com.example.calculator

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var inputText: TextView
    private lateinit var outputText: TextView
    private var input = ""
    private var operator = ""
    private var operand1 = 0
    private var operand2 = 0
    private var result = 0
    private var operatorCount = 0  // Compte le nombre d'opérateurs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialisation de inputText et outputText
        inputText = findViewById(R.id.input)
        outputText = findViewById(R.id.output)

        // Ajouter un OnLongClickListener pour copier le résultat sur appui long
        outputText.setOnLongClickListener {
            CopierNombre()
            true  // Renvoie true pour indiquer que l'événement est géré
        }

        // Ajouter un OnLongClickListener pour coller dans inputText
        inputText.setOnLongClickListener {
            CollerNombre()
            true
        }

        // Ajouter un OnClickListener pour chaque bouton
        val buttonIds = listOf(
            R.id.button_0, R.id.button_1, R.id.button_2, R.id.button_3,
            R.id.button_4, R.id.button_5, R.id.button_6, R.id.button_7,
            R.id.button_8, R.id.button_9, R.id.button_addition, R.id.button_subtraction,
            R.id.button_multiply, R.id.button_division, R.id.button_equals,
            R.id.button_clear, R.id.button_delast,
            R.id.button_modulo, R.id.button_dot, R.id.button_neg
        )

        buttonIds.forEach { id ->
            findViewById<View>(id).setOnClickListener { onButtonClick(it) }
        }
    }

    private fun onButtonClick(view: View) {
        when (view.id) {
            R.id.button_clear -> clear()
            R.id.button_equals -> calculateResult()
            R.id.button_addition -> setOperator("+")
            R.id.button_subtraction -> setOperator("-")
            R.id.button_multiply -> setOperator("×")
            R.id.button_division -> setOperator("÷")
            R.id.button_modulo -> setOperator("%")
            R.id.button_delast -> deleteLast()
            R.id.button_dot -> addDot()
            R.id.button_neg -> negation()
            else -> {
                val value = (view as TextView).text.toString()
                input += value
                inputText.text = input
            }
        }
    }

    private fun addDot() {
        if (input.isNotEmpty() && !input.contains(".") && operator.isEmpty()) {
            input += "."
            inputText.text = input
        }
    }

    private fun setOperator(op: String) {
        // Si un opérateur est déjà présent, on exécute le calcul avant de continuer
        if (operator.isNotEmpty() && operatorCount >= 1) {
            calculateResult()  // Calcule le résultat et réinitialise pour une nouvelle opération
            operand1 = result
            operator = op
            input = "$result $operator " // Prépare input pour le prochain calcul
            operatorCount = 1
            inputText.text = input
        } else {
            // Sinon, définir l'opérateur et ajouter au input
            if (input.isNotEmpty()) {
                operand1 = input.replace(".", "").toIntOrNull() ?: 0
                operator = op
                operatorCount++
                input += " $op "
                inputText.text = input
            }
        }
    }

    private fun calculateResult() {
        val lastOperand = input.substringAfterLast(" ").replace(".", "").toIntOrNull()
        operand2 = lastOperand ?: return

        result = when (operator) {
            "+" -> operand1 + operand2
            "-" -> operand1 - operand2
            "×" -> operand1 * operand2
            "÷" -> if (operand2 != 0) operand1 / operand2 else 0
            "%" -> operand1 % operand2
            else -> 0
        }

        // Affiche le résultat dans outputText
        inputText.text = ""  // Efface l'input
        outputText.text = result.toString()  // Affiche le résultat

        // Réinitialise les variables pour une nouvelle opération
        input = result.toString()
        operator = ""
        operatorCount = 0
    }

    private fun deleteLast() {
        if (input.isNotEmpty()) {
            input = input.dropLast(1)
            inputText.text = input
        }
    }

    private fun clear() {
        input = ""
        operand1 = 0
        operand2 = 0
        result = 0
        operator = ""
        operatorCount = 0
        inputText.text = ""
        outputText.text = ""
    }

    private fun negation() {
        if (input.isNotEmpty()) {
            val lastOperand = input.substringAfterLast(" ").toIntOrNull()
            if (lastOperand != null) {
                input = input.dropLast(lastOperand.toString().length) + (-lastOperand).toString()
                inputText.text = input
            } else {
                Toast.makeText(this, "Impossible d'inverser le signe", Toast.LENGTH_SHORT).show()
            }
        }
    }


    // Fonction pour copier le résultat
    private fun CopierNombre() {
        val resultText = outputText.text.toString()
        val inputtt = inputText.text.toString()

        if (inputtt.isNotEmpty()) {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("Résultat", inputtt)
            clipboard.setPrimaryClip(clip)

            // Affiche un message de confirmation
            Toast.makeText(this, "Résultat copié dans le presse-papier", Toast.LENGTH_SHORT).show()
        }


        if (resultText.isNotEmpty()) {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("Résultat", resultText)
            clipboard.setPrimaryClip(clip)

            // Affiche un message de confirmation
            Toast.makeText(this, "Résultat copié dans le presse-papier", Toast.LENGTH_SHORT).show()
        } else {
            // Si le résultat est vide, affiche un message d'erreur
            Toast.makeText(this, "Aucun résultat à copier", Toast.LENGTH_SHORT).show()
        }
    }


    // Fonction pour coller un nombre dans inputText
    private fun CollerNombre() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clipData = clipboard.primaryClip
        if (clipData != null && clipData.itemCount > 0) {
            val pastedText = clipData.getItemAt(0).text.toString()
            val number = pastedText.toIntOrNull() // Accepte les nombres décimaux

            if (number != null) {
                input += if (number % 1 == 0) number.toInt().toString() else number.toString()
                inputText.text = input
            } else {
                Toast.makeText(this, "Le presse-papier ne contient pas un nombre valide", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Le presse-papier est vide", Toast.LENGTH_SHORT).show()
        }
    }


}
